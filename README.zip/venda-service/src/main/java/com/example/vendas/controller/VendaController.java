package com.example.vendas.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.*;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/vendas")
public class VendaController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostMapping
    public Map<String, Object> realizarVenda(@RequestBody Map<String, Object> venda) {
        try {
            System.out.println("Recebendo venda: " + venda);

            String insertVendaSql = "INSERT INTO vendas (cliente_id) VALUES (?)";
            jdbcTemplate.update(insertVendaSql, venda.get("cliente_id"));

            Integer vendaId = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);

            System.out.println("Venda registrada com ID: " + vendaId);

            List<Map<String, Object>> produtos = (List<Map<String, Object>>) venda.get("produtos");
            for (Map<String, Object> produto : produtos) {
                System.out.println("Adicionando produto: " + produto);
                String insertProdutoSql = "INSERT INTO vendas_produtos (venda_id, produto_id, quantidade) VALUES (?, ?, ?)";
                jdbcTemplate.update(insertProdutoSql, vendaId, produto.get("produto_id"), produto.get("quantidade"));
            }

            return Map.of("mensagem", "Venda registrada com sucesso", "venda_id", vendaId);
        } catch (Exception e) {
            e.printStackTrace();
            return Map.of("erro", "Erro ao registrar a venda");
        }
    }

    @GetMapping
    public List<Map<String, Object>> listarVendas() {
        System.out.println("Listando vendas...");

        String sql = "SELECT v.id, IFNULL(c.nome, 'Cliente não encontrado') AS cliente_nome, v.data_venda " +
                "FROM vendas v " +
                "LEFT JOIN clientes c ON v.cliente_id = c.id";

        List<Map<String, Object>> vendas = jdbcTemplate.queryForList(sql);

        for (Map<String, Object> venda : vendas) {
            int vendaId = (int) venda.get("id");

            String produtoSql = "SELECT p.nome, p.valor AS preco, vp.quantidade " +
                    "FROM vendas_produtos vp " +
                    "JOIN produtos p ON vp.produto_id = p.id " +
                    "WHERE vp.venda_id = ?";

            List<Map<String, Object>> produtos = jdbcTemplate.queryForList(produtoSql, vendaId);
            venda.put("produtos", produtos);
        }

        return vendas;
    }
}
